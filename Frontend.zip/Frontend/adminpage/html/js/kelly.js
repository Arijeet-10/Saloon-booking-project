/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
am4internal_webpackJsonp(["fa15"],{"Z+ar":function(c,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var b=t("aCit"),j=t("8ZqG"),O=function(c){Object(b.b)(c,"ColorSet")&&(c.list=[Object(j.c)("#F3C300"),Object(j.c)("#875692"),Object(j.c)("#F38400"),Object(j.c)("#A1CAF1"),Object(j.c)("#BE0032"),Object(j.c)("#C2B280"),Object(j.c)("#848482"),Object(j.c)("#008856"),Object(j.c)("#E68FAC"),Object(j.c)("#0067A5"),Object(j.c)("#F99379"),Object(j.c)("#604E97"),Object(j.c)("#F6A600"),Object(j.c)("#B3446C"),Object(j.c)("#DCD300"),Object(j.c)("#882D17"),Object(j.c)("#8DB600"),Object(j.c)("#654522"),Object(j.c)("#E25822"),Object(j.c)("#2B3D26"),Object(j.c)("#F2F3F4"),Object(j.c)("#222222")],c.minLightness=.2,c.maxLightness=.7,c.reuse=!0)};window.am4themes_kelly=O}},["Z+ar"]);
//# sourceMappingURL=kelly.js.map